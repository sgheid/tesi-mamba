"""Scoperta automatica delle fasi.

Ogni file .py in questa cartella che definisce una variabile FASE diventa una
voce del menu. I file che iniziano con "_" sono ignorati (es. il modello).
Per aggiungere la Fase 3a: copia _modello_nuova_fase.py in fase3a_....py e compilalo.
"""
import importlib
import pkgutil
import re
import traceback


def _chiave_ordinamento(fase):
    # "2a" -> (2, "a"), "10" -> (10, ""): ordine naturale nel menu
    m = re.match(r"(\d+)(.*)", fase.codice)
    return (int(m.group(1)), m.group(2)) if m else (999, fase.codice)


def carica_fasi(ricarica=False):
    """Restituisce (fasi ordinate, errori). Un file con errori non blocca le altre fasi."""
    fasi, errori = [], []
    for modulo in pkgutil.iter_modules(__path__):
        if modulo.name.startswith("_"):
            continue
        nome = f"{__name__}.{modulo.name}"
        try:
            mod = importlib.import_module(nome)
            if ricarica:
                mod = importlib.reload(mod)
            if hasattr(mod, "FASE"):
                fasi.append(mod.FASE)
        except Exception:
            errori.append((modulo.name, traceback.format_exc(limit=3)))
    return sorted(fasi, key=_chiave_ordinamento), errori
