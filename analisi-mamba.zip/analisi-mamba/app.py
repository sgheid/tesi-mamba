"""Analisi dei modi di Mamba - interfaccia grafica locale.

Avvio (dalla cartella del progetto, con l'ambiente virtuale attivo):
    streamlit run app.py
Si apre il browser su http://localhost:8501. Tutto gira sul tuo PC: niente rete.

Struttura:
    app.py      questa interfaccia (solo presentazione)
    nucleo/     caricamento modelli, testo, risultati, grafica, Excel
    fasi/       una fase per file: aggiungere un file = aggiungere una voce al menu
"""
import hashlib
import html
import os
import time
from datetime import datetime

import pandas as pd
import streamlit as st

from fasi import carica_fasi
from nucleo import grafica as g
from nucleo.excel import crea_excel, nome_file, salva_excel
from nucleo.formato import FORMATI
from nucleo.modelli import (carica_e_verifica, cartella_cache_predefinita, dispositivi_disponibili,
                            libera, trova_modelli)
from nucleo.risultato import Contesto
from nucleo.testo import MAX_TOKEN_PREDEFINITO, TESTO_ESEMPIO, prepara

CARTELLA_APP = os.path.dirname(os.path.abspath(__file__))
CARTELLA_RISULTATI = os.path.join(CARTELLA_APP, "risultati")

st.set_page_config(page_title="Analisi modi di Mamba", page_icon="〰", layout="wide",
                   initial_sidebar_state="expanded")

st.markdown("""
<style>
  .block-container {padding-top: 2.2rem; max-width: 1280px;}
  section[data-testid="stSidebar"] {width: 350px !important;}
  h1, h2, h3 {letter-spacing: -0.01em;}
  .riquadri {display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
             gap: 12px; margin: 6px 0 18px 0;}
  .riquadro {background: #ffffff; border: 1px solid rgba(11,11,11,0.10); border-radius: 10px;
             padding: 12px 14px 11px 14px;}
  .riquadro .et {font-size: 0.80rem; color: #52514e; margin-bottom: 3px;}
  .riquadro .val {font-size: 1.45rem; font-weight: 600; color: #0b0b0b; line-height: 1.25;
                  font-variant-numeric: tabular-nums;}
  .riquadro .nota {font-size: 0.78rem; color: #898781; margin-top: 3px; line-height: 1.3;}
  .stato {display: inline-block; font-size: 0.72rem; font-weight: 600; padding: 1px 7px;
          border-radius: 999px; margin-left: 6px; vertical-align: middle;}
  .stato.ok {background: rgba(12,163,12,0.12); color: #006300;}
  .stato.attenzione {background: rgba(250,178,25,0.22); color: #7a5200;}
  .contesto {font-size: 0.85rem; color: #52514e; background: #f3f2ee; border-radius: 8px;
             padding: 7px 12px; margin-bottom: 10px;}
  .controllo {font-size: 0.88rem; margin: 2px 0;}
  .sottotitolo-grafico {color: #52514e; font-size: 0.92rem; margin-top: -6px;}
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Stato della sessione
# ---------------------------------------------------------------------------
def stato(chiave, valore):
    if chiave not in st.session_state:
        st.session_state[chiave] = valore


stato("cartella", cartella_cache_predefinita())
stato("model", None)
stato("tok", None)
stato("info", None)
stato("controlli", [])
stato("dispositivo", dispositivi_disponibili()[0][0])
stato("testo", None)            # dict: ids, token, testo, fonte, n_originali, impronta
stato("risultati", {})          # codice fase -> Risultato
stato("messaggio", None)

DISPOSITIVI = dict(dispositivi_disponibili())


def impronta_testo(testo, max_token):
    return hashlib.sha1(f"{max_token}|{testo}".encode("utf-8")).hexdigest()[:10]


# ---------------------------------------------------------------------------
# Azioni
# ---------------------------------------------------------------------------
def sfoglia_cartella():
    """Finestra di Windows per scegliere la cartella (funziona perche' il server gira sul tuo PC)."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        radice = tk.Tk()
        radice.withdraw()
        radice.wm_attributes("-topmost", 1)
        scelta = filedialog.askdirectory(initialdir=st.session_state.cartella,
                                         title="Cartella che contiene i modelli")
        radice.destroy()
        if scelta:
            st.session_state.cartella = os.path.normpath(scelta)
    except Exception as e:
        st.session_state.messaggio = ("warning", f"Finestra di selezione non disponibile ({e}). "
                                                 "Scrivi o incolla il percorso nella casella.")


def carica_modello(modello, dispositivo):
    if st.session_state.model is not None:
        st.session_state.model = None
        st.session_state.tok = None
        libera()
    with st.spinner(f"Carico e verifico {modello.nome}..."):
        model, tok, info, controlli = carica_e_verifica(modello, dispositivo)
    st.session_state.update(model=model, tok=tok, info=info, controlli=controlli, dispositivo=dispositivo)
    # il testo va ritokenizzato con il tokenizer del nuovo modello
    t = st.session_state.testo
    if model is not None and t is not None:
        imposta_testo(t["grezzo"], t["fonte"], t["max_token"])


def imposta_testo(grezzo, fonte, max_token):
    tok = st.session_state.tok
    ids, token, testo, n_originali = prepara(tok, grezzo, st.session_state.dispositivo, max_token)
    st.session_state.testo = dict(grezzo=grezzo, fonte=fonte, max_token=max_token, ids=ids, token=token,
                                  testo=testo, n_originali=n_originali,
                                  impronta=impronta_testo(testo, max_token))


# ---------------------------------------------------------------------------
# Barra laterale
# ---------------------------------------------------------------------------
fasi, errori_fasi = carica_fasi()

with st.sidebar:
    st.markdown("### ① Modello")
    st.text_input("Cartella dei modelli", key="cartella",
                  help="Predefinita: la cache di Hugging Face, dove from_pretrained salva i modelli "
                       "scaricati. Va bene anche una cartella con config.json e i pesi.")
    st.button("Sfoglia…", on_click=sfoglia_cartella)

    trovati = trova_modelli(st.session_state.cartella)
    solo_mamba = st.toggle("Mostra solo modelli Mamba-1", value=True)
    elenco = [m for m in trovati if m.is_mamba] if solo_mamba else trovati
    if not trovati:
        st.caption("Nessun modello trovato in questa cartella.")
    elif not elenco:
        st.caption(f"{len(trovati)} modelli trovati, nessuno Mamba-1. Disattiva il filtro per vederli.")

    scelto = None
    if elenco:
        scelto = st.selectbox("Modello", elenco,
                              format_func=lambda m: m.nome if m.is_mamba else f"{m.nome} [{m.tipo}]")
        st.caption(f"Pesi: {scelto.dimensione_gb:.2f} GB su disco · commit {scelto.commit}")
    disp = st.radio("Esegui su", list(DISPOSITIVI), format_func=DISPOSITIVI.get, horizontal=True,
                    index=list(DISPOSITIVI).index(st.session_state.dispositivo))
    if scelto is not None and disp == "cpu" and scelto.dimensione_gb > 2:
        st.caption("⚠ Modello grande su CPU: servono circa "
                   f"{scelto.dimensione_gb * 1.3:.1f} GB di RAM liberi.")
    if st.button("Carica e verifica", type="primary", disabled=scelto is None, width="stretch"):
        carica_modello(scelto, disp)

    info = st.session_state.info
    if info is not None:
        st.success(f"**{info['nome']}** caricato su {DISPOSITIVI[st.session_state.dispositivo]}", icon="✅")

    st.divider()
    st.markdown("### ② Testo")
    if st.session_state.model is None:
        st.caption("Carica prima un modello: il testo va tokenizzato con il suo tokenizer.")
    else:
        fonte = st.radio("Fonte", ["Testo di esempio", "Incolla un testo", "File .txt"],
                         label_visibility="collapsed")
        grezzo = caricato = None
        if fonte == "Testo di esempio":
            st.caption("Il testo sulla teoria del controllo usato per le misure già fatte (211 token).")
            grezzo = TESTO_ESEMPIO
        elif fonte == "Incolla un testo":
            grezzo = st.text_area("Testo", height=160, placeholder="Incolla qui il testo (in inglese, "
                                  "come i dati di addestramento di Mamba).", label_visibility="collapsed")
        else:
            caricato = st.file_uploader("File di testo", type=["txt", "md"], label_visibility="collapsed")
            if caricato is not None:
                grezzo = caricato.getvalue().decode("utf-8", errors="replace")
        max_token = st.number_input("Token massimi", 16, 8192, MAX_TOKEN_PREDEFINITO, step=64,
                                    help="I testi più lunghi vengono troncati. Con il 1.4B sulla GPU da 8 GB "
                                         "1024 è un limite prudente.")
        if st.button("Usa questo testo", disabled=not (grezzo and grezzo.strip()), width="stretch"):
            nome_fonte = {"Testo di esempio": "testo di esempio", "Incolla un testo": "testo incollato"}.get(
                fonte, f"file {getattr(caricato, 'name', '')}")
            imposta_testo(grezzo.strip(), nome_fonte, int(max_token))
        t = st.session_state.testo
        if t is not None:
            troncato = f" (troncato da {t['n_originali']})" if t["n_originali"] > t["max_token"] else ""
            st.info(f"In uso: **{t['ids'].shape[1]} token**{troncato} · {t['fonte']}", icon="📄")

    st.divider()
    st.markdown("### ③ Fase")
    if not fasi:
        st.error("Nessuna fase trovata nella cartella fasi/.")
        fase = None
    else:
        fase = st.radio("Fase", fasi, label_visibility="collapsed",
                        format_func=lambda f: f"Fase {f.codice} · {f.nome}",
                        captions=[f.breve for f in fasi])
    for nome, errore in errori_fasi:
        st.error(f"Errore nel file fasi/{nome}.py", icon="⚠️")
        with st.expander("Dettagli"):
            st.code(errore)
    if st.button("Ricarica le fasi", help="Rilegge i file in fasi/ dopo averne aggiunto o modificato uno."):
        carica_fasi(ricarica=True)
        st.rerun()
    st.divider()
    salva_auto = st.toggle("Salva ogni risultato anche in risultati/", value=True,
                           help=f"Cartella: {CARTELLA_RISULTATI}")

if st.session_state.messaggio:
    tipo, testo_msg = st.session_state.messaggio
    getattr(st, tipo)(testo_msg)
    st.session_state.messaggio = None


# ---------------------------------------------------------------------------
# Pagina principale
# ---------------------------------------------------------------------------
def mostra_controlli(controlli):
    for c in controlli:
        segno = "✅" if c.ok else "❌"
        dettaglio = f" — <span style='color:#898781'>{html.escape(c.dettaglio)}</span>" if c.dettaglio else ""
        st.markdown(f"<div class='controllo'>{segno} {html.escape(c.descrizione)}{dettaglio}</div>",
                    unsafe_allow_html=True)


def riquadri(indicatori):
    parti = []
    for ind in indicatori:
        badge = ""
        if ind.stato == "ok":
            badge = "<span class='stato ok'>✓ ok</span>"
        elif ind.stato == "attenzione":
            badge = "<span class='stato attenzione'>! da notare</span>"
        nota = f"<div class='nota'>{html.escape(ind.nota)}</div>" if ind.nota else ""
        parti.append(f"<div class='riquadro'><div class='et'>{html.escape(ind.etichetta)}{badge}</div>"
                     f"<div class='val'>{html.escape(ind.valore)}</div>{nota}</div>")
    st.markdown(f"<div class='riquadri'>{''.join(parti)}</div>", unsafe_allow_html=True)


def tabella(ris):
    """Tabella per strato: i numeri sono gia' formattati come nel file Excel (stesse cifre)."""
    intestazioni = [f"{c.titolo} ({c.sottotitolo})" if c.sottotitolo else c.titolo for c in ris.colonne]
    df = pd.DataFrame([[FORMATI[c.formato][0](r.get(c.chiave)) for c in ris.colonne] for r in ris.righe],
                      columns=intestazioni)
    configurazione = {h: st.column_config.TextColumn(h, alignment="center" if c.chiave == "strato" else "right",
                                                     width="small" if c.chiave == "strato" else None)
                      for h, c in zip(intestazioni, ris.colonne)}
    if ris.evidenzia:
        df["Nota"] = [ris.evidenzia.get(r.get("strato"), "") for r in ris.righe]
        configurazione["Nota"] = st.column_config.TextColumn("Nota", width="medium")
    evid = {i for i, r in enumerate(ris.righe) if r.get("strato") in ris.evidenzia}
    stile = df.style.apply(lambda riga: ["background-color: #fff2cc" if riga.name in evid else ""] * len(riga),
                           axis=1)
    st.dataframe(stile, hide_index=True, width="stretch", column_config=configurazione,
                 height=min(38 + 35 * len(df), 720))


def pagina_benvenuto():
    st.title("Analisi dei modi di Mamba")
    st.markdown(
        "Strumento locale per misurare poli, passi di campionamento e margini di stabilità di un modello "
        "Mamba-1, strato per strato. Tutto gira sul tuo PC, senza connessione.")
    c1, c2, c3 = st.columns(3)
    c1.markdown("**① Scegli il modello**  \nNella barra a sinistra, dalla cartella dei modelli scaricati. "
                "Il programma lo carica in FP32 e controlla che sia analizzabile.")
    c2.markdown("**② Scegli il testo**  \nServe alle fasi che fanno leggere il modello (2a, 2b). "
                "La Fase 1 legge solo i pesi.")
    c3.markdown("**③ Esegui una fase**  \nRisultati in riquadri, grafici e tabella, con la guida alla lettura. "
                "Ogni fase si può scaricare in Excel.")
    if st.session_state.controlli:
        st.subheader("Esito dell'ultima verifica")
        mostra_controlli(st.session_state.controlli)
        st.error("Il modello non è stato caricato: vedi il controllo non superato qui sopra.")


def intestazione_modello(info):
    st.title(info["nome"])
    c = st.columns(5)
    c[0].metric("Strati", info["strati"])
    c[1].metric("Canali per strato", f"{info['canali']:,}".replace(",", " "))
    c[2].metric("Stati per canale", info["stati"])
    c[3].metric("Poli continui", f"{info['poli_continui']:,}".replace(",", " "))
    c[4].metric("Pesi su disco", f"{info['dimensione_gb']:.2f} GB")
    with st.expander("Verifica del modello superata", icon="✅"):
        mostra_controlli(st.session_state.controlli)
        st.caption(f"Cartella: `{info['percorso']}` · commit {info['commit']} · "
                   f"rango di Δ: {info['rank_delta']}")


def chiave_esecuzione(fase, parametri):
    t = st.session_state.testo
    return (st.session_state.info["percorso"], st.session_state.dispositivo,
            t["impronta"] if (fase.usa_testo and t) else None, tuple(sorted(parametri.items())))


def esegui_fase(fase, parametri):
    info = st.session_state.info
    t = st.session_state.testo if fase.usa_testo else None
    barra = st.progress(0.0, text=f"Fase {fase.codice} in corso...")
    ctx = Contesto(
        model=st.session_state.model, tok=st.session_state.tok, info_modello=info,
        dispositivo=st.session_state.dispositivo, nome_dispositivo=DISPOSITIVI[st.session_state.dispositivo],
        ids=t["ids"] if t else None, token=t["token"] if t else [],
        testo=t["testo"] if t else None, fonte_testo=t["fonte"] if t else None, parametri=parametri,
        avanzamento=lambda f, m="": barra.progress(min(max(f, 0.0), 1.0), text=f"Fase {fase.codice}: {m}"))
    t0 = time.time()
    try:
        ris = fase.esegui(ctx)
    except Exception as e:
        import torch
        barra.empty()
        if isinstance(e, torch.cuda.OutOfMemoryError):
            torch.cuda.empty_cache()
            st.error("Memoria della GPU esaurita: riduci i token massimi o usa un testo più corto.")
        else:
            st.error(f"Errore durante la fase: {type(e).__name__}: {e}")
            st.exception(e)
        return
    barra.empty()
    ris.info = dict(
        modello=info["nome"], percorso=info["percorso"], commit=info["commit"],
        struttura=f"{info['strati']} strati × {info['canali']} canali × {info['stati']} stati",
        dispositivo=DISPOSITIVI[st.session_state.dispositivo], data=datetime.now(),
        durata=time.time() - t0, parametri=parametri,
        testo=t["testo"] if t else None, fonte_testo=t["fonte"] if t else None,
        n_token=int(t["ids"].shape[1]) if t else None,
        chiave=chiave_esecuzione(fase, parametri))
    if salva_auto:
        try:
            ris.info["file"] = salva_excel(ris, CARTELLA_RISULTATI)
        except OSError as e:
            st.warning(f"Salvataggio in risultati/ non riuscito: {e}")
    st.session_state.risultati[fase.codice] = ris


def mostra_risultato(fase, ris, parametri):
    i = ris.info
    contesto = (f"<b>{html.escape(i['modello'])}</b> · {html.escape(i['dispositivo'])} · {html.escape(ris.note_formato)}"
                f" · {i['data']:%d/%m/%Y %H:%M} · {i['durata']:.1f} s")
    if i.get("n_token"):
        contesto += f" · testo: {i['n_token']} token ({html.escape(i['fonte_testo'])})"
    st.markdown(f"<div class='contesto'>{contesto}</div>", unsafe_allow_html=True)
    if i.get("chiave") != chiave_esecuzione(fase, parametri):
        st.warning("Questo risultato è stato ottenuto con un modello, un testo o dei parametri diversi da "
                   "quelli selezionati ora. Premi **Esegui** per aggiornarlo.", icon="🔁")

    riquadri(ris.indicatori)

    sch_graf, sch_tab, sch_leg, sch_testo = st.tabs(["Grafici", "Tabella per strato", "Come leggere le colonne",
                                                     "Testo analizzato"])
    with sch_graf:
        for k, graf in enumerate(ris.grafici):
            st.subheader(graf.titolo)
            if graf.spiegazione:
                st.markdown(f"<div class='sottotitolo-grafico'>{html.escape(graf.spiegazione)}</div>",
                            unsafe_allow_html=True)
            st.plotly_chart(graf.figura, width="stretch", config=g.CONFIG, theme=None,
                            key=f"grafico_{ris.codice}_{k}")
            if graf.come_leggere:
                with st.expander("Come leggere questo grafico", icon="💡"):
                    st.markdown(graf.come_leggere)
        st.caption("Suggerimento: l'icona a forma di fotocamera sopra ogni grafico salva un PNG ad alta "
                   "risoluzione, pronto per la tesi. Trascinando si ingrandisce; doppio clic per tornare indietro.")
    with sch_tab:
        st.markdown(f"**{ris.titolo}**  \n{ris.descrizione}")
        tabella(ris)
        if ris.evidenzia:
            st.caption("Le righe evidenziate in giallo sono quelle citate nella colonna Nota.")
    with sch_leg:
        for nome_col, spiegazione in ris.legenda:
            st.markdown(f"**{nome_col}** — {spiegazione}")
    with sch_testo:
        if i.get("testo"):
            st.text_area("Testo analizzato", i["testo"], height=260, disabled=True, label_visibility="collapsed")
        else:
            st.caption("Questa fase non usa il testo: legge solo i pesi.")

    c1, c2 = st.columns([1, 2])
    c1.download_button("⬇ Scarica i risultati in Excel", data=crea_excel(ris), file_name=nome_file(ris),
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                       width="stretch")
    if i.get("file"):
        c2.caption(f"Salvato anche in `{i['file']}`")


if st.session_state.model is None or fase is None:
    pagina_benvenuto()
else:
    intestazione_modello(st.session_state.info)
    st.divider()
    st.header(f"Fase {fase.codice} · {fase.nome}")
    with st.expander("Cosa misura questa fase", icon="📘", expanded=fase.codice not in st.session_state.risultati):
        st.markdown(fase.spiegazione)

    parametri = {}
    if fase.parametri:
        colonne = st.columns(min(len(fase.parametri), 4))
        for col, p in zip(colonne, fase.parametri):
            parametri[p.chiave] = col.selectbox(p.etichetta, p.scelte,
                                                index=p.scelte.index(p.predefinito) if p.predefinito in p.scelte else 0,
                                                help=p.aiuto or None, key=f"param_{fase.codice}_{p.chiave}")

    manca_testo = fase.usa_testo and st.session_state.testo is None
    if manca_testo:
        st.info("Questa fase fa leggere un testo al modello: sceglilo nella sezione ② della barra laterale "
                "(per ritrovare i risultati già ottenuti usa il testo di esempio).", icon="📄")
    if st.button(f"▶ Esegui la Fase {fase.codice}", type="primary", disabled=manca_testo):
        esegui_fase(fase, parametri)

    ris = st.session_state.risultati.get(fase.codice)
    if ris is not None:
        mostra_risultato(fase, ris, parametri)
