"""Sonde (forward hook) per leggere le grandezze interne mentre il modello legge un testo.

La sonda e' attaccata a x_proj di ogni strato: la sua uscita contiene, nelle prime
time_step_rank colonne, l'ingresso di dt_proj, da cui si ricalcola Delta esattamente
come fa il modello. Non servono i kernel CUDA di mamba-ssm.
"""
import torch
import torch.nn.functional as F


def esegui_con_sonde(model, ids, crea_hook):
    """crea_hook(i, mixer) -> funzione hook(modulo, ingresso, uscita)."""
    strati = model.backbone.layers
    maniglie = [layer.mixer.x_proj.register_forward_hook(crea_hook(i, layer.mixer))
                for i, layer in enumerate(strati)]
    try:
        with torch.no_grad():
            model(ids, use_cache=False)
    finally:
        for m in maniglie:
            m.remove()


def ingresso_delta(mixer, uscita_x_proj):
    """Le prime time_step_rank colonne dell'uscita di x_proj, primo (unico) elemento del batch."""
    return uscita_x_proj[0, :, :mixer.time_step_rank]


def delta_fp32(mixer, ts):
    """Delta come lo calcola il modello: softplus(W_dt * ts + b_dt), in FP32. Forma (token, canali)."""
    return F.softplus(ts.float() @ mixer.dt_proj.weight.float().T + mixer.dt_proj.bias.float())


def delta_fp64(mixer, ts):
    """Stesso calcolo in FP64: riferimento 'esatto'."""
    return F.softplus(ts.double() @ mixer.dt_proj.weight.double().T + mixer.dt_proj.bias.double())
