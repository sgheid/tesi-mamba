"""Formattazione dei numeri, uguale a schermo, nelle tabelle e nel file Excel."""
import math


def fmt_sci(x):
    """1.234e-07 -> '1.23e-07'."""
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "-"
    if isinstance(x, float) and math.isinf(x):
        return "infinito"
    return f"{x:.2e}"


def fmt_int(n):
    """495310 -> '495 310' (spazio come separatore delle migliaia)."""
    return f"{int(n):,}".replace(",", " ")


def fmt_perc(p):
    """p e' una frazione. Tre cifre significative: 0.0229 -> '2.29 %', 2.16e-7 -> '0.0000216 %'."""
    if p == 0:
        return "0 %"
    x = p * 100
    decimali = max(0, 2 - math.floor(math.log10(abs(x))))
    return f"{x:.{decimali}f} %"


def fmt_dec(x):
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return "-"
    return f"{x:.1f}"


def fmt_testo(x):
    return "" if x is None else str(x)


# formato -> (funzione per lo schermo, formato numerico di Excel)
FORMATI = {
    "sci": (fmt_sci, "0.00E+00"),
    "int": (fmt_int, "#,##0"),
    "perc": (fmt_perc, "0.00000%"),
    "dec": (fmt_dec, "0.0"),
    "testo": (fmt_testo, "@"),
}
