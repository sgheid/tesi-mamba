"""Ricerca dei modelli salvati in locale, caricamento e verifica.

Riconosce due tipi di cartella:
  - la cache di Hugging Face (models--org--nome/snapshots/<commit>/config.json),
    dove finiscono i modelli scaricati con from_pretrained("state-spaces/...");
  - una cartella qualsiasi che contiene config.json (modello salvato con save_pretrained).
Il caricamento avviene sempre e solo dal disco (local_files_only): niente rete.
"""
import gc
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

import torch

ESTENSIONI_PESI = (".safetensors", ".bin")


@dataclass
class ModelloLocale:
    nome: str            # es. state-spaces/mamba-130m-hf
    percorso: str        # cartella con config.json
    commit: str          # cartella snapshot della cache, oppure "-"
    tipo: str            # model_type in config.json (mamba, mamba2, gpt2...)
    dimensione_gb: float

    @property
    def is_mamba(self):
        return self.tipo == "mamba"

    def etichetta(self):
        segno = "" if self.is_mamba else f"   [{self.tipo}: non analizzabile]"
        return f"{self.nome}   ({self.dimensione_gb:.2f} GB){segno}"


def cartella_cache_predefinita():
    """Dove Hugging Face salva i modelli scaricati, su Windows come su Linux."""
    if os.environ.get("HF_HUB_CACHE"):
        return os.environ["HF_HUB_CACHE"]
    if os.environ.get("HF_HOME"):
        return os.path.join(os.environ["HF_HOME"], "hub")
    return str(Path.home() / ".cache" / "huggingface" / "hub")


def _leggi_tipo(cartella):
    try:
        with open(os.path.join(cartella, "config.json"), encoding="utf-8") as f:
            return json.load(f).get("model_type", "sconosciuto")
    except (OSError, ValueError):
        return "illeggibile"


def _dimensione_gb(cartella):
    totale = 0
    for f in os.listdir(cartella):
        if f.endswith(ESTENSIONI_PESI):
            try:
                totale += os.path.getsize(os.path.join(cartella, f))   # segue i collegamenti della cache
            except OSError:
                pass
    return totale / 1024 ** 3


def trova_modelli(cartella):
    """Elenco dei modelli trovati in `cartella` (cache HF o cartelle con config.json)."""
    cartella = os.path.expanduser(cartella.strip().strip('"'))
    if not os.path.isdir(cartella):
        return []
    trovati = []

    def aggiungi(nome, percorso, commit):
        if os.path.isfile(os.path.join(percorso, "config.json")):
            trovati.append(ModelloLocale(nome, percorso, commit, _leggi_tipo(percorso), _dimensione_gb(percorso)))

    # 1) la cartella scelta e' gia' un modello
    aggiungi(os.path.basename(os.path.normpath(cartella)), cartella, "-")
    if trovati:
        return trovati

    for voce in sorted(os.listdir(cartella)):
        sotto = os.path.join(cartella, voce)
        if not os.path.isdir(sotto):
            continue
        # 2) struttura della cache: models--org--nome/snapshots/<commit>
        if voce.startswith("models--"):
            nome = voce[len("models--"):].replace("--", "/")
            snapshots = os.path.join(sotto, "snapshots")
            if not os.path.isdir(snapshots):
                continue
            commit_main = None
            try:
                with open(os.path.join(sotto, "refs", "main"), encoding="utf-8") as f:
                    commit_main = f.read().strip()
            except OSError:
                pass
            commit_presenti = sorted(os.listdir(snapshots))
            if commit_main in commit_presenti:            # versione principale per prima
                commit_presenti.remove(commit_main)
                commit_presenti.insert(0, commit_main)
            for c in commit_presenti:
                aggiungi(nome if c == commit_presenti[0] else f"{nome} @ {c[:10]}",
                         os.path.join(snapshots, c), c[:10])
        # 3) cartelle salvate con save_pretrained (anche un livello piu' in basso)
        else:
            if os.path.isfile(os.path.join(sotto, "config.json")):
                aggiungi(voce, sotto, "-")
            else:
                for voce2 in sorted(os.listdir(sotto)):
                    sotto2 = os.path.join(sotto, voce2)
                    if os.path.isdir(sotto2):
                        aggiungi(f"{voce}/{voce2}", sotto2, "-")
    return trovati


def dispositivi_disponibili():
    """[(codice, descrizione)] con la GPU per prima, se PyTorch la vede."""
    elenco = []
    if torch.cuda.is_available():
        elenco.append(("cuda", f"GPU {torch.cuda.get_device_name(0)}"))
    elenco.append(("cpu", "CPU"))
    return elenco


@dataclass
class Controllo:
    descrizione: str
    ok: bool
    dettaglio: str = ""


def carica_e_verifica(modello: ModelloLocale, dispositivo: str):
    """Carica il modello dal disco e controlla che sia analizzabile dalle fasi.

    Restituisce (model, tok, info, controlli). Se un controllo fallisce, model e' None
    e l'ultimo controllo dice perche'.
    """
    from transformers import AutoTokenizer, MambaForCausalLM

    controlli = []

    def fallito(descrizione, dettaglio):
        controlli.append(Controllo(descrizione, False, dettaglio))
        return None, None, None, controlli

    # 1. tipo di architettura
    if modello.tipo != "mamba":
        aiuto = (" Mamba-2 ha una A scalare per testa: le fasi sono scritte per Mamba-1."
                 if modello.tipo == "mamba2" else "")
        return fallito("Architettura Mamba-1 (model_type = mamba)",
                       f"config.json indica '{modello.tipo}'.{aiuto}")
    controlli.append(Controllo("Architettura Mamba-1 (model_type = mamba)", True))

    # 2. tokenizer
    try:
        tok = AutoTokenizer.from_pretrained(modello.percorso, local_files_only=True)
    except Exception as e:
        return fallito("Tokenizer letto dalla cartella", f"{type(e).__name__}: {e}")
    controlli.append(Controllo("Tokenizer letto dalla cartella", True, type(tok).__name__))

    # 3. pesi, direttamente sul dispositivo e in FP32 (la baseline della tesi)
    t0 = time.time()
    try:
        try:
            model = MambaForCausalLM.from_pretrained(modello.percorso, local_files_only=True,
                                                     dtype=torch.float32, device_map=dispositivo)
        except (TypeError, ValueError, ImportError):
            # transformers vecchio (usa torch_dtype) o accelerate assente (niente device_map):
            # carico in RAM e poi sposto sul dispositivo
            try:
                model = MambaForCausalLM.from_pretrained(modello.percorso, local_files_only=True,
                                                         dtype=torch.float32)
            except TypeError:
                model = MambaForCausalLM.from_pretrained(modello.percorso, local_files_only=True,
                                                         torch_dtype=torch.float32)
            model = model.to(dispositivo)
        model = model.float().eval()
    except torch.cuda.OutOfMemoryError:
        libera()
        return fallito("Pesi caricati in FP32", "Memoria della GPU esaurita: il modello non entra nella VRAM.")
    except Exception as e:
        libera()
        return fallito("Pesi caricati in FP32", f"{type(e).__name__}: {e}")
    controlli.append(Controllo("Pesi caricati in FP32", True, f"in {time.time() - t0:.1f} s"))

    # 4. struttura interna che le fasi leggono
    try:
        strati = model.backbone.layers
        mancanti = [attr for attr in ("A_log", "x_proj", "dt_proj", "time_step_rank")
                    if not hasattr(strati[0].mixer, attr)]
    except AttributeError as e:
        mancanti = [str(e)]
    if mancanti:
        model = None
        libera()
        return fallito("Struttura interna (A_log, x_proj, dt_proj)", "Mancano: " + ", ".join(mancanti))
    controlli.append(Controllo("Struttura interna (A_log, x_proj, dt_proj)", True,
                               f"{len(strati)} strati"))

    # 5. pesi numericamente sani
    with torch.no_grad():
        non_finiti = sum(int((~torch.isfinite(l.mixer.A_log)).sum().item()) for l in strati)
    if non_finiti:
        model = None
        libera()
        return fallito("A_log senza NaN o infiniti", f"{non_finiti} valori non finiti")
    controlli.append(Controllo("A_log senza NaN o infiniti", True))

    # 6. prova di lettura su poche parole
    try:
        ids = tok("Control theory", return_tensors="pt").input_ids.to(dispositivo)
        with torch.no_grad():
            logits = model(ids, use_cache=False).logits
        if not torch.isfinite(logits).all():
            raise ValueError("uscita non finita")
    except Exception as e:
        model = None
        libera()
        return fallito("Prova di lettura su un testo breve", f"{type(e).__name__}: {e}")
    controlli.append(Controllo("Prova di lettura su un testo breve", True))

    cfg = model.config
    info = dict(nome=modello.nome, percorso=modello.percorso, commit=modello.commit,
                strati=cfg.num_hidden_layers, canali=cfg.intermediate_size, stati=cfg.state_size,
                rank_delta=strati[0].mixer.time_step_rank,
                poli_continui=cfg.num_hidden_layers * cfg.intermediate_size * cfg.state_size,
                dimensione_gb=modello.dimensione_gb)
    return model, tok, info, controlli


def libera(model=None):
    """Toglie il modello dalla memoria (RAM o VRAM) prima di caricarne un altro."""
    del model
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
