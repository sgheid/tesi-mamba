"""Strutture dati comuni a tutte le fasi.

Una fase riceve un Contesto e restituisce un Risultato. L'interfaccia e
l'esportazione Excel sanno mostrare qualsiasi Risultato: aggiungere una fase
non richiede di toccare ne' l'una ne' l'altra.
"""
from dataclasses import dataclass, field
from typing import Any, Callable, Optional


@dataclass
class Parametro:
    """Un'opzione che la fase chiede all'utente prima di partire (es. il formato FP16/BF16)."""
    chiave: str
    etichetta: str
    scelte: list                 # valori possibili, mostrati in un menu a tendina
    predefinito: Any = None
    aiuto: str = ""


@dataclass
class Fase:
    """Descrizione di una fase. Ogni file in fasi/ ne definisce una, chiamata FASE."""
    codice: str                  # "1", "2a", "3a"... ordina il menu
    nome: str                    # titolo breve
    breve: str                   # una riga per il menu
    spiegazione: str             # markdown: cosa misura, perche', un esempio
    usa_testo: bool              # True se la fase fa leggere un testo al modello
    esegui: Callable             # funzione(ctx: Contesto) -> Risultato
    parametri: list = field(default_factory=list)


@dataclass
class Contesto:
    """Tutto cio' che una fase puo' usare."""
    model: Any                   # MambaForCausalLM, in FP32
    tok: Any                     # tokenizer
    info_modello: dict           # nome, percorso, commit, strati, canali, stati...
    dispositivo: str             # "cuda" o "cpu"
    nome_dispositivo: str        # es. "GPU NVIDIA GeForce RTX 2060 SUPER"
    ids: Any = None              # tensor (1, token) oppure None
    token: list = field(default_factory=list)   # testo di ogni token, per i grafici
    testo: Optional[str] = None
    fonte_testo: Optional[str] = None
    parametri: dict = field(default_factory=dict)
    avanzamento: Callable = lambda frazione, messaggio="": None

    @property
    def n_token(self):
        return 0 if self.ids is None else int(self.ids.shape[1])


@dataclass
class Colonna:
    chiave: str                  # nome del campo nelle righe
    titolo: str                  # prima riga dell'intestazione
    sottotitolo: str = ""        # seconda riga (unita' o significato)
    formato: str = "sci"         # sci | int | perc | dec | testo


@dataclass
class Indicatore:
    """Un numero chiave mostrato in evidenza (riquadro in cima ai risultati)."""
    etichetta: str
    valore: str
    nota: str = ""
    stato: Optional[str] = None  # None | "ok" | "attenzione"


@dataclass
class Grafico:
    titolo: str
    figura: Any                  # plotly.graph_objects.Figure
    spiegazione: str = ""        # una o due frasi sotto il titolo
    come_leggere: str = ""       # markdown, mostrato a richiesta
    dati: Any = None             # pandas.DataFrame con i dati del grafico (va nell'Excel)


@dataclass
class Risultato:
    codice: str
    titolo: str
    descrizione: str
    colonne: list
    righe: list                  # lista di dict, una per strato
    indicatori: list
    legenda: list                # [(nome colonna, spiegazione)]
    grafici: list = field(default_factory=list)
    evidenzia: dict = field(default_factory=dict)   # strato -> nota
    note_formato: str = "FP32"
    # compilati dall'interfaccia dopo l'esecuzione
    info: dict = field(default_factory=dict)
