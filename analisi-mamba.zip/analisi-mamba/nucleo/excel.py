"""Esportazione di un Risultato in un unico file Excel (.xlsx).

Foglio 1 (la fase): informazioni sulla misura, testo, sintesi, tabella per strato, legenda.
Fogli successivi: i dati di ogni grafico, per poterli ridisegnare nella tesi.
"""
import io
import math
import os
import re
from datetime import datetime

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .formato import FORMATI

BLU_SCURO = "1F3864"


def nome_file(ris):
    data = ris.info.get("data", datetime.now())
    nome = ris.info.get("modello", "modello").split("/")[-1].split(" @ ")[0]
    return f"{data:%Y%m%d_%H%M%S}_{nome}_Fase{ris.codice}.xlsx"


def _nome_foglio(testo, usati):
    base = re.sub(r"[\\/*?:\[\]]", "", testo)[:28] or "Dati"
    nome, k = base, 2
    while nome in usati:
        nome, k = f"{base[:25]} {k}", k + 1
    usati.add(nome)
    return nome


def crea_excel(ris):
    """Restituisce il file Excel come bytes (per il download)."""
    wb = openpyxl.Workbook()
    ws = wb.active
    usati = set()
    ws.title = _nome_foglio(f"Fase {ris.codice}", usati)

    col = ris.colonne
    n_col = len(col)
    ultima = max(n_col + 1, 7)
    grassetto = Font(bold=True)
    titolo_sez = Font(bold=True, size=12, color=BLU_SCURO)
    sfondo_int = PatternFill("solid", fgColor=BLU_SCURO)
    sfondo_evid = PatternFill("solid", fgColor="FFF2CC")
    bordo = Border(bottom=Side(style="thin", color="BFBFBF"))
    sinistra = Alignment(horizontal="left", vertical="top", wrap_text=True)

    def coppia(r, etichetta, valore):
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=ultima)
        e = ws.cell(r, 1, etichetta)
        e.font = grassetto
        e.alignment = sinistra
        v = ws.cell(r, 3, valore)
        v.alignment = sinistra
        return v

    riga = 1
    ws.cell(riga, 1, ris.titolo).font = Font(bold=True, size=14)
    riga += 1
    ws.cell(riga, 1, ris.descrizione).font = Font(italic=True)
    riga += 2

    info = ris.info
    ws.cell(riga, 1, "INFORMAZIONI").font = titolo_sez
    riga += 1
    elenco = [
        ("Modello", info.get("modello", "")),
        ("Cartella", info.get("percorso", "")),
        ("Commit dei pesi", info.get("commit", "")),
        ("Struttura", info.get("struttura", "")),
        ("Dispositivo", info.get("dispositivo", "")),
        ("Formato numerico", ris.note_formato),
        ("Data e ora", f"{info.get('data', datetime.now()):%d/%m/%Y %H:%M:%S}"),
        ("Durata", f"{info.get('durata', 0):.1f} s"),
    ]
    for k, v in info.get("parametri", {}).items():
        elenco.append((f"Parametro: {k}", str(v)))
    testo = info.get("testo")
    if testo is not None:
        elenco += [("Fonte del testo", info.get("fonte_testo", "")),
                   ("Token analizzati", str(info.get("n_token", "")))]
    for etichetta, valore in elenco:
        coppia(riga, etichetta, valore)
        riga += 1
    if testo is not None:
        coppia(riga, "Testo analizzato", testo[:32000])
        caratteri_per_riga = 23 * (ultima - 2)
        n_righe = sum(len(p) // caratteri_per_riga + 1 for p in testo.split("\n"))
        ws.row_dimensions[riga].height = min(409, 15 * (n_righe + 1))
        riga += 1
    riga += 1

    ws.cell(riga, 1, "SINTESI").font = titolo_sez
    riga += 1
    for ind in ris.indicatori:
        valore = ind.valore + (f"  -  {ind.nota}" if ind.nota else "")
        coppia(riga, ind.etichetta, valore)
        riga += 1
    riga += 1

    ws.cell(riga, 1, "RISULTATI PER STRATO").font = titolo_sez
    riga += 1
    for j, c in enumerate(col, start=1):
        cella = ws.cell(riga, j, f"{c.titolo}\n{c.sottotitolo}".strip())
        cella.font = Font(bold=True, color="FFFFFF")
        cella.fill = sfondo_int
        cella.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
    ws.row_dimensions[riga].height = 32
    riga_intestazione = riga
    riga += 1
    for r in ris.righe:
        evid = r.get("strato") in ris.evidenzia
        for j, c in enumerate(col, start=1):
            valore = r.get(c.chiave)
            if isinstance(valore, float) and (math.isinf(valore) or math.isnan(valore)):
                valore = None
            cella = ws.cell(riga, j, valore)
            cella.number_format = FORMATI[c.formato][1]
            cella.border = bordo
            if c.chiave == "strato":
                cella.alignment = Alignment(horizontal="center")
            if evid:
                cella.fill = sfondo_evid
        if evid:
            nota = ws.cell(riga, n_col + 1, ris.evidenzia[r["strato"]])
            nota.font = Font(italic=True)
            nota.alignment = Alignment(indent=1)
        riga += 1
    riga += 1

    ws.cell(riga, 1, "COME LEGGERE LE COLONNE").font = titolo_sez
    riga += 1
    for nome_col, spiegazione in ris.legenda:
        coppia(riga, nome_col, spiegazione)
        riga += 1

    ws.column_dimensions["A"].width = 12
    ws.column_dimensions["B"].width = 30
    for j in range(3, ultima + 1):
        ws.column_dimensions[get_column_letter(j)].width = 20
    ws.column_dimensions[get_column_letter(n_col + 1)].width = 26
    ws.freeze_panes = ws.cell(riga_intestazione + 1, 1)
    ws.page_setup.orientation = "landscape"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0

    # Un foglio con i dati di ogni grafico
    for g in ris.grafici:
        if g.dati is None or len(g.dati) == 0:
            continue
        wg = wb.create_sheet(_nome_foglio(g.titolo, usati))
        wg.cell(1, 1, g.titolo).font = Font(bold=True, size=12)
        if g.spiegazione:
            wg.cell(2, 1, g.spiegazione).font = Font(italic=True)
        for j, nome in enumerate(g.dati.columns, start=1):
            c = wg.cell(4, j, str(nome))
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = sfondo_int
            wg.column_dimensions[get_column_letter(j)].width = max(14, len(str(nome)) + 2)
        for i, riga_dati in enumerate(g.dati.itertuples(index=False), start=5):
            for j, v in enumerate(riga_dati, start=1):
                if isinstance(v, float) and (math.isinf(v) or math.isnan(v)):
                    v = None
                elif hasattr(v, "item"):
                    v = v.item()
                wg.cell(i, j, v)
        wg.freeze_panes = "A5"

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()


def salva_excel(ris, cartella="risultati"):
    """Scrive il file anche su disco e restituisce il percorso."""
    os.makedirs(cartella, exist_ok=True)
    percorso = os.path.join(cartella, nome_file(ris))
    with open(percorso, "wb") as f:
        f.write(crea_excel(ris))
    return percorso
