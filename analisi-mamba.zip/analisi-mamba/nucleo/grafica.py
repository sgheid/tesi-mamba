"""Stile comune dei grafici (Plotly), uguale per tutte le fasi.

Palette: blu come tinta principale (una sola serie = un solo colore),
grigio caldo per assi e griglia, rosso/verde riservati agli stati
(ok / attenzione) e sempre accompagnati da un'etichetta.
"""
import math

import plotly.graph_objects as go

# Tinte (palette di riferimento, modo chiaro)
BLU = "#2a78d6"
BLU_CHIARO = "#86b6ef"
BLU_TENUE = "rgba(42, 120, 214, 0.14)"
ARANCIO = "#eb6834"
ROSSO_STATO = "#d03b3b"
ROSSO_TENUE = "rgba(208, 59, 59, 0.08)"
VERDE_STATO = "#0ca30c"
GRIGIO_ZONA = "rgba(137, 135, 129, 0.13)"

INCHIOSTRO = "#0b0b0b"
INCHIOSTRO_2 = "#52514e"
TENUE = "#898781"
GRIGLIA = "#e1e0d9"
ASSE = "#c3c2b7"
SUPERFICIE = "#fcfcfb"

# Scala sequenziale a una tinta (chiaro = poco, scuro = molto)
SCALA_BLU = [[0.0, "#eef4fc"], [0.15, "#cde2fb"], [0.3, "#9ec5f4"], [0.45, "#6da7ec"],
             [0.6, "#3987e5"], [0.75, "#256abf"], [0.9, "#184f95"], [1.0, "#0d366b"]]

CARATTERE = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif'

# Configurazione della barra degli strumenti: la fotocamera salva un PNG ad alta risoluzione
CONFIG = {
    "displaylogo": False,
    "modeBarButtonsToRemove": ["lasso2d", "select2d", "autoScale2d"],
    "toImageButtonOptions": {"format": "png", "scale": 3, "filename": "grafico_mamba"},
}

# Soglia FP32: un numero x < 1 viene arrotondato a 1 se 1 - x < 2^-25 (meta' della
# distanza 2^-24 tra 1 e il numero rappresentabile immediatamente inferiore).
SOGLIA_FP32 = 2.0 ** -25


def nuova_figura(asse_x, asse_y, log_y=False, altezza=420, hover_unificato=True):
    fig = go.Figure()
    fig.update_layout(
        height=altezza,
        margin=dict(l=70, r=24, t=16, b=56),
        paper_bgcolor=SUPERFICIE,
        plot_bgcolor=SUPERFICIE,
        font=dict(family=CARATTERE, size=13, color=INCHIOSTRO_2),
        hovermode="x unified" if hover_unificato else "closest",
        hoverlabel=dict(bgcolor="white", bordercolor=ASSE, font=dict(family=CARATTERE, color=INCHIOSTRO)),
        legend=dict(orientation="h", yanchor="bottom", y=1.01, xanchor="left", x=0,
                    font=dict(color=INCHIOSTRO_2), bgcolor="rgba(0,0,0,0)"),
        bargap=0.12,
    )
    stile_asse = dict(showgrid=True, gridcolor=GRIGLIA, gridwidth=1, zeroline=False,
                      linecolor=ASSE, ticks="outside", tickcolor=ASSE, ticklen=4,
                      tickfont=dict(color=TENUE), title_font=dict(color=INCHIOSTRO_2))
    fig.update_xaxes(title_text=asse_x, **stile_asse)
    fig.update_yaxes(title_text=asse_y, **stile_asse)
    fig.update_xaxes(showgrid=False)
    if log_y:
        fig.update_yaxes(type="log", exponentformat="power", dtick=1)
    return fig


def asse_strati(fig, n_strati):
    """Asse x con un'etichetta ogni 1, 2, 4... strati a seconda di quanti sono."""
    passo = 1 if n_strati <= 24 else (2 if n_strati <= 48 else 4)
    fig.update_xaxes(tickmode="linear", tick0=0, dtick=passo, range=[-0.6, n_strati - 0.4])


def asse_decadi(fig, asse, minimo, massimo):
    """Asse in decadi (valori = log10) etichettato come 10^k."""
    k_min, k_max = math.floor(minimo), math.ceil(massimo)
    passo = 1 if k_max - k_min <= 16 else 2
    valori = list(range(k_min, k_max + 1, passo))
    testo = [f"10<sup>{k}</sup>" for k in valori]
    if asse == "x":
        fig.update_xaxes(tickmode="array", tickvals=valori, ticktext=testo)
    else:
        fig.update_yaxes(tickmode="array", tickvals=valori, ticktext=testo)


def _e_log(fig, asse):
    return (fig.layout.yaxis.type if asse == "y" else fig.layout.xaxis.type) == "log"


def _etichetta(fig, asse, valore, testo, colore, ancora_x, ancora_y, x=None, y=None):
    """Etichetta di una zona o di una soglia. Sugli assi logaritmici Plotly vuole la
    posizione delle annotazioni gia' in log10: la converto qui."""
    pos = math.log10(valore) if _e_log(fig, asse) else valore
    if asse == "y":
        fig.add_annotation(x=x, xref="paper", y=pos, yref="y", text=testo, showarrow=False,
                           xanchor=ancora_x, yanchor=ancora_y, font=dict(size=11, color=colore))
    else:
        fig.add_annotation(x=pos, xref="x", y=y, yref="paper", text=testo, showarrow=False,
                           xanchor=ancora_x, yanchor=ancora_y, font=dict(size=11, color=colore))


def zona(fig, asse, da, a, testo, colore=GRIGIO_ZONA):
    """Fascia di riferimento con l'etichetta dentro, vicino al bordo superiore (o sinistro)."""
    stile = dict(fillcolor=colore, line_width=0, layer="below")
    if asse == "y":
        fig.add_hrect(y0=da, y1=a, **stile)
        _etichetta(fig, "y", a, " " + testo, INCHIOSTRO_2, "left", "top", x=0)
    else:
        fig.add_vrect(x0=da, x1=a, **stile)
        _etichetta(fig, "x", da, " " + testo, INCHIOSTRO_2, "left", "top", y=1)


def linea_soglia(fig, asse, valore, testo, colore=ROSSO_STATO):
    """Linea tratteggiata con l'etichetta sopra (orizzontale) o a destra in alto (verticale)."""
    stile = dict(line=dict(color=colore, width=1.5, dash="dash"))
    if asse == "y":
        fig.add_hline(y=valore, **stile)
        _etichetta(fig, "y", valore, testo + " ", colore, "right", "bottom", x=1)
    else:
        fig.add_vline(x=valore, **stile)
        _etichetta(fig, "x", valore, " " + testo, colore, "left", "top", y=0.93)


def scala_log(fig, asse, minimo, massimo, margine=0.3):
    """Fissa l'intervallo di un asse logaritmico sui dati e dirada le tacche se le decadi sono tante."""
    lo = math.floor(math.log10(minimo)) - margine
    hi = math.ceil(math.log10(massimo)) + margine
    decadi = hi - lo
    dtick = 1 if decadi <= 10 else (2 if decadi <= 20 else 3)
    impostazioni = dict(range=[lo, hi], dtick=dtick)
    if asse == "y":
        fig.update_yaxes(**impostazioni)
    else:
        fig.update_xaxes(**impostazioni)


def fascia_min_mediana_max(fig, x, y_min, y_med, y_max, nomi, unita="", formato=".2e"):
    """Tre serie della stessa grandezza: fascia tra minimo e massimo, mediana in evidenza.

    nomi = (nome del bordo superiore, nome della mediana, nome del bordo inferiore).
    """
    sup, med, inf = nomi
    fig.add_trace(go.Scatter(x=x, y=y_max, name=sup, mode="lines",
                             line=dict(color=BLU_CHIARO, width=1.5),
                             hovertemplate=f"%{{y:{formato}}}{unita}<extra>{sup}</extra>"))
    fig.add_trace(go.Scatter(x=x, y=y_min, name=inf, mode="lines",
                             line=dict(color=BLU_CHIARO, width=1.5, dash="dot"),
                             fill="tonexty", fillcolor=BLU_TENUE,
                             hovertemplate=f"%{{y:{formato}}}{unita}<extra>{inf}</extra>"))
    fig.add_trace(go.Scatter(x=x, y=y_med, name=med, mode="lines+markers",
                             line=dict(color=BLU, width=2), marker=dict(size=7, color=BLU,
                                                                        line=dict(color=SUPERFICIE, width=1.5)),
                             hovertemplate=f"%{{y:{formato}}}{unita}<extra>{med}</extra>"))
