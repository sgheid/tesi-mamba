"""Nucleo del programma: modelli, testo, risultati, grafica, esportazione.

Nulla qui dipende dall'interfaccia (Streamlit): le fasi usano solo il nucleo,
quindi si possono riusare anche da uno script o da un notebook.
"""
